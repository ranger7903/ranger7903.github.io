# -*- coding: utf-8 -*-
import os, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from app import core
from app.i18n import S

PASS = []

def check(name, cond):
    if not cond:
        raise AssertionError(name)
    PASS.append(name)


def make(d, names):
    ps = []
    for n in names:
        p = os.path.join(d, n)
        open(p, 'w').write('x')
        ps.append(p)
    return ps


def test_replace_and_sanitize():
    with tempfile.TemporaryDirectory() as d:
        ps = make(d, ['보고서_초안.txt', '보고서_최종.txt', '무관.txt'])
        plan = core.build_plan(ps, {'mode': 'replace', 'find': '보고서', 'repl': '주간보고'})
        check('replace 2건만', len(plan) == 2)
        check('replace 결과', os.path.basename(plan[0][1]) == '주간보고_초안.txt')
        plan2 = core.build_plan(ps[:1], {'mode': 'replace', 'find': '초안', 'repl': 'a:b?'})
        check('금지문자 치환', os.path.basename(plan2[0][1]) == '보고서_a_b_.txt')


def test_prefix_suffix_number_date():
    with tempfile.TemporaryDirectory() as d:
        ps = make(d, ['a.jpg', 'b.jpg'])
        plan = core.build_plan(ps, {'mode': 'prefix', 'text': '여행_'})
        check('prefix', os.path.basename(plan[0][1]) == '여행_a.jpg')
        plan = core.build_plan(ps, {'mode': 'suffix', 'text': '_완료'})
        check('suffix 확장자 보존', os.path.basename(plan[0][1]) == 'a_완료.jpg')
        plan = core.build_plan(ps, {'mode': 'number', 'base': '사진', 'start': 7, 'pad': 3})
        check('number 순번', [os.path.basename(n) for _, n in plan] == ['사진_007.jpg', '사진_008.jpg'])
        plan = core.build_plan(ps, {'mode': 'date', 'today': '2026-08-25'})
        check('date', os.path.basename(plan[0][1]) == '2026-08-25_a.jpg')


def test_collision():
    with tempfile.TemporaryDirectory() as d:
        ps = make(d, ['x1.txt', 'x2.txt', '문서.txt'])
        # x1, x2 모두 '문서'로 → 기존 문서.txt 와 서로끼리 충돌 → (2)(3)
        plan = core.build_plan(ps[:2], {'mode': 'number', 'base': '문서', 'start': 1, 'pad': 0})
        names = [os.path.basename(n) for _, n in plan]
        check('collision 회피', names == ['문서_1.txt', '문서_2.txt'])
        plan2 = core.build_plan(ps[:2], {'mode': 'replace', 'find': 'x1', 'repl': '문서'})
        check('기존 파일과 충돌 시 (2)', os.path.basename(plan2[0][1]) == '문서 (2).txt')


def test_apply_and_undo():
    with tempfile.TemporaryDirectory() as d:
        logd = os.path.join(d, '_log')
        ps = make(d, ['가.txt', '나.txt'])
        plan = core.build_plan(ps, {'mode': 'prefix', 'text': '새_'})
        done, errors, log = core.apply_plan(plan, logd)
        check('apply 2건', len(done) == 2 and not errors)
        check('파일 실제 변경', os.path.exists(os.path.join(d, '새_가.txt')))
        check('로그 생성', log and os.path.exists(log))
        restored, errs = core.undo_from_log(log)
        check('undo 복원', len(restored) == 2 and os.path.exists(os.path.join(d, '가.txt')))
        check('undo 후 새 이름 없음', not os.path.exists(os.path.join(d, '새_가.txt')))


def test_natural_sort():
    names = ['사진10.jpg', '사진2.jpg', '사진1.jpg']
    s = sorted(names, key=core.natural_key)
    check('자연 정렬', s == ['사진1.jpg', '사진2.jpg', '사진10.jpg'])


def test_no_change_excluded():
    with tempfile.TemporaryDirectory() as d:
        ps = make(d, ['a.txt'])
        plan = core.build_plan(ps, {'mode': 'replace', 'find': '없는말', 'repl': 'x'})
        check('무변화 제외', plan == [])
        plan = core.build_plan(ps, {'mode': 'prefix', 'text': ''})
        check('빈 규칙 제외', plan == [])


def test_i18n():
    check('i18n 키 일치', set(S['ko']) == set(S['en']))
    for lang in S:
        for k, v in S[lang].items():
            check(f'i18n {lang}.{k}', bool(v))


if __name__ == '__main__':
    test_replace_and_sanitize(); test_prefix_suffix_number_date()
    test_collision(); test_apply_and_undo(); test_natural_sort()
    test_no_change_excluded(); test_i18n()
    print(f'OK — {len(PASS)} checks passed')
