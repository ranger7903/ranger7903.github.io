# -*- coding: utf-8 -*-
"""이름표 붙이기 — 파일명 일괄 변경 핵심 로직 (표준 라이브러리만)
미리보기 → 실행 → 되돌리기. 원본 내용은 건드리지 않고 이름만 바꾼다."""
import os
import re
import json
import datetime

BAD = '\\/:*?"<>|'


def sanitize(name):
    """윈도우에서 못 쓰는 글자는 _ 로"""
    out = ''.join('_' if c in BAD else c for c in name)
    return out.strip() or '_'


def build_plan(paths, rule):
    """paths: 파일 전체경로 목록 (표시 순서대로)
    rule: dict(mode=..., ...)
      - replace: find → repl (파일명에서 찾아 바꾸기)
      - prefix:  text 를 앞에
      - suffix:  text 를 확장자 앞에
      - number:  base + 번호 (start, pad)  예: 사진_001
      - date:    오늘 날짜를 앞에 (YYYY-MM-DD_)
    반환: [(old_path, new_path)], 충돌은 (2) 규칙으로 해소, 변화 없는 항목 제외
    """
    mode = rule.get('mode')
    today = rule.get('today') or datetime.date.today().strftime('%Y-%m-%d')
    plan = []
    taken = set()          # 이번 계획에서 쓰기로 한 이름들 (소문자 비교)
    existing = {}
    for p in paths:
        d = os.path.dirname(p)
        if d not in existing:
            try:
                existing[d] = {f.lower() for f in os.listdir(d)}
            except OSError:
                existing[d] = set()
    for i, p in enumerate(paths):
        d, fname = os.path.split(p)
        stem, ext = os.path.splitext(fname)
        if mode == 'replace':
            find = rule.get('find', '')
            if not find:
                continue
            new_stem = stem.replace(find, rule.get('repl', ''))
        elif mode == 'prefix':
            new_stem = rule.get('text', '') + stem
        elif mode == 'suffix':
            new_stem = stem + rule.get('text', '')
        elif mode == 'number':
            base = rule.get('base') or '파일'
            n = int(rule.get('start', 1)) + i
            new_stem = f"{base}_{n:0{int(rule.get('pad', 3))}d}"
        elif mode == 'date':
            new_stem = f"{today}_{stem}"
        else:
            continue
        new_stem = sanitize(new_stem)
        if not new_stem or new_stem == stem:
            continue
        new_name = new_stem + ext
        # 충돌 해소: 폴더의 기존 파일 + 이번 계획의 이름과 겹치면 (2)
        cand = new_name
        k = 2
        others = (existing[d] - {fname.lower()}) | {t for (dd, t) in taken if dd == d}
        while cand.lower() in others:
            cand = f"{new_stem} ({k}){ext}"
            k += 1
        taken.add((d, cand.lower()))
        plan.append((p, os.path.join(d, cand)))
    return plan


def apply_plan(plan, log_dir):
    """계획 실행. 성공 목록을 되돌리기 로그(json)로 저장."""
    done = []
    errors = []
    for old, new in plan:
        try:
            os.rename(old, new)
            done.append((old, new))
        except OSError as e:
            errors.append((old, str(e)))
    log_path = None
    if done:
        os.makedirs(log_dir, exist_ok=True)
        log_path = os.path.join(
            log_dir, datetime.datetime.now().strftime('되돌리기_%Y%m%d_%H%M%S.json'))
        with open(log_path, 'w', encoding='utf-8') as f:
            json.dump([{'old': o, 'new': n} for o, n in done], f,
                      ensure_ascii=False, indent=1)
    return done, errors, log_path


def undo_from_log(log_path):
    """로그를 읽어 역순으로 이름 복원"""
    with open(log_path, encoding='utf-8') as f:
        entries = json.load(f)
    restored, errors = [], []
    for e in reversed(entries):
        try:
            if os.path.exists(e['new']) and not os.path.exists(e['old']):
                os.rename(e['new'], e['old'])
                restored.append(e['old'])
            else:
                errors.append((e['new'], 'skip'))
        except OSError as err:
            errors.append((e['new'], str(err)))
    return restored, errors


def natural_key(name):
    """사람 눈 순서 정렬: 사진2 < 사진10"""
    return [int(t) if t.isdigit() else t.lower()
            for t in re.split(r'(\d+)', name)]
