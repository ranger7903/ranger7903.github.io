# -*- coding: utf-8 -*-
"""한국어/영어 문자열"""
import locale

S = {
 'ko': {
  'app': "밸류스 이름표 붙이기",
  'tagline': "파일 이름을 한꺼번에, 예쁘게 — 밸류스가 드리는 선물이에요",
  'free': "무료 나눔",
  'step1': "① 파일 고르기", 'step2': "② 규칙 정하기", 'step3': "③ 미리보고 실행",
  'pick_files': "📂 파일 고르기 (여러 개)", 'pick_folder': "🗂 폴더째 고르기",
  'no_file': "아직 고른 파일이 없어요",
  'files_n': "{n}개 선택됨",
  'mode_replace': "찾아 바꾸기", 'mode_prefix': "앞에 붙이기", 'mode_suffix': "뒤에 붙이기",
  'mode_number': "번호 매기기", 'mode_date': "날짜 붙이기",
  'find': "찾을 말", 'repl': "바꿀 말", 'text': "붙일 말",
  'base': "새 이름", 'start': "시작 번호",
  'date_hint': "오늘 날짜(YYYY-MM-DD)를 이름 앞에 붙여요",
  'preview': "👀 미리보기", 'run': "▶  이름 바꾸기",
  'undo': "↩ 방금 것 되돌리기",
  'col_old': "지금 이름", 'col_new': "바뀔 이름",
  'no_change': "바뀌는 파일이 없어요. 규칙을 확인해 주세요.",
  'done': "완성! {n}개의 이름을 바꿨어요",
  'done_err': " (실패 {e}개 — 사용 중인 파일은 닫고 다시)",
  'undone': "{n}개를 원래 이름으로 되돌렸어요",
  'no_log': "되돌릴 기록이 없어요",
  'promise': "이름만 바꿔요 — 내용은 그대로 · 겹치면 (2) · 되돌리기 한 번이면 원위치",
  'gift': "이 프로그램은 무료예요. 유용했다면 valuestools.kr 의 다른 도구들도 구경해 주세요 🧡",
 },
 'en': {
  'app': "VALUES Name Tags",
  'tagline': "Rename files in one sweep — a free gift from VALUES",
  'free': "Free gift",
  'step1': "① Pick files", 'step2': "② Set the rule", 'step3': "③ Preview & go",
  'pick_files': "📂 Choose files (multiple)", 'pick_folder': "🗂 Choose a folder",
  'no_file': "No files chosen yet",
  'files_n': "{n} selected",
  'mode_replace': "Find & replace", 'mode_prefix': "Add in front", 'mode_suffix': "Add at end",
  'mode_number': "Numbering", 'mode_date': "Date prefix",
  'find': "Find", 'repl': "Replace with", 'text': "Text",
  'base': "Base name", 'start': "Start at",
  'date_hint': "Adds today's date (YYYY-MM-DD) in front",
  'preview': "👀 Preview", 'run': "▶  Rename",
  'undo': "↩ Undo last run",
  'col_old': "Current name", 'col_new': "New name",
  'no_change': "Nothing would change. Check the rule.",
  'done': "Done! Renamed {n} files",
  'done_err': " ({e} failed — close files in use and retry)",
  'undone': "Restored {n} original names",
  'no_log': "Nothing to undo",
  'promise': "Only names change — contents untouched · duplicates get (2) · one-click undo",
  'gift': "This tool is free. If it helped, come see our other tools at valuestools.kr 🧡",
 },
}


def detect_lang():
    try:
        loc = locale.getdefaultlocale()[0] or ''
    except Exception:
        loc = ''
    return 'ko' if loc.lower().startswith('ko') else 'en'


class T:
    def __init__(self, lang=None):
        self.lang = lang or detect_lang()

    def __call__(self, key, **kw):
        s = S.get(self.lang, S['en']).get(key) or S['en'].get(key, key)
        return s.format(**kw) if kw else s

    def toggle(self):
        self.lang = 'en' if self.lang == 'ko' else 'ko'
        return self.lang
