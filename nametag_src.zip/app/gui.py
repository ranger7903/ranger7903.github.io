# -*- coding: utf-8 -*-
"""이름표 붙이기 — 화면 (3단계: 고르기 → 규칙 → 미리보고 실행)"""
import os
import sys
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from app import core
from app.i18n import T

CREAM = '#FAF5EC'; CARD = '#FFFDF8'; TERRA = '#C0684A'; SAGE = '#7E9B77'
INK = '#41382E'; LINE = '#E4D9C6'


def log_dir():
    d = os.path.join(os.environ.get('APPDATA', os.path.expanduser('~')),
                     '밸류스', '이름표붙이기')
    os.makedirs(d, exist_ok=True)
    return d


class App:
    def __init__(self, root):
        self.root = root
        self.t = T()
        self.paths = []
        self.plan = []
        self.last_log = None
        root.configure(bg=CREAM)
        root.geometry('960x680')
        self.build()
        self.retext()

    def build(self):
        top = tk.Frame(self.root, bg=CREAM); top.pack(fill='x', padx=14, pady=(12, 4))
        self.title_lbl = tk.Label(top, bg=CREAM, fg=INK, font=('Malgun Gothic', 15, 'bold'))
        self.title_lbl.pack(side='left')
        self.free_lbl = tk.Label(top, bg=SAGE, fg='white', font=('Malgun Gothic', 9, 'bold'),
                                 padx=8, pady=2)
        self.free_lbl.pack(side='left', padx=8)
        self.lang_btn = tk.Button(top, command=self.toggle_lang, bg=CARD, fg=INK,
                                  relief='flat', padx=10)
        self.lang_btn.pack(side='right')

        # ① 파일 고르기
        s1 = tk.Frame(self.root, bg=CREAM); s1.pack(fill='x', padx=14, pady=4)
        self.s1_lbl = tk.Label(s1, bg=CREAM, fg=TERRA, font=('Malgun Gothic', 11, 'bold'))
        self.s1_lbl.pack(anchor='w')
        row = tk.Frame(s1, bg=CREAM); row.pack(fill='x')
        self.b_files = tk.Button(row, command=self.pick_files, bg=TERRA, fg='white',
                                 relief='flat', padx=10, pady=4)
        self.b_files.pack(side='left', padx=3)
        self.b_folder = tk.Button(row, command=self.pick_folder, bg=TERRA, fg='white',
                                  relief='flat', padx=10, pady=4)
        self.b_folder.pack(side='left', padx=3)
        self.count_lbl = tk.Label(row, bg=CREAM, fg='#9A8F7F')
        self.count_lbl.pack(side='left', padx=10)

        # ② 규칙
        s2 = tk.Frame(self.root, bg=CREAM); s2.pack(fill='x', padx=14, pady=4)
        self.s2_lbl = tk.Label(s2, bg=CREAM, fg=TERRA, font=('Malgun Gothic', 11, 'bold'))
        self.s2_lbl.pack(anchor='w')
        row2 = tk.Frame(s2, bg=CREAM); row2.pack(fill='x')
        self.mode = tk.StringVar(value='replace')
        self.mode_btns = {}
        for m in ('replace', 'prefix', 'suffix', 'number', 'date'):
            bt = tk.Radiobutton(row2, variable=self.mode, value=m, command=self.on_mode,
                                bg=CREAM, fg=INK, selectcolor=CARD,
                                font=('Malgun Gothic', 10))
            bt.pack(side='left', padx=2)
            self.mode_btns[m] = bt
        self.inp = tk.Frame(s2, bg=CREAM); self.inp.pack(fill='x', pady=4)
        self.e1_lbl = tk.Label(self.inp, bg=CREAM, fg=INK)
        self.e1 = tk.Entry(self.inp, width=22)
        self.e2_lbl = tk.Label(self.inp, bg=CREAM, fg=INK)
        self.e2 = tk.Entry(self.inp, width=22)
        self.hint_lbl = tk.Label(self.inp, bg=CREAM, fg='#9A8F7F')

        # ③ 미리보기·실행
        s3 = tk.Frame(self.root, bg=CREAM); s3.pack(fill='both', expand=True, padx=14, pady=4)
        self.s3_lbl = tk.Label(s3, bg=CREAM, fg=TERRA, font=('Malgun Gothic', 11, 'bold'))
        self.s3_lbl.pack(anchor='w')
        row3 = tk.Frame(s3, bg=CREAM); row3.pack(fill='x', pady=2)
        self.b_prev = tk.Button(row3, command=self.preview, bg=SAGE, fg='white',
                                relief='flat', padx=12, pady=4)
        self.b_prev.pack(side='left', padx=3)
        self.b_run = tk.Button(row3, command=self.run, bg=TERRA, fg='white',
                               relief='flat', padx=12, pady=4)
        self.b_run.pack(side='left', padx=3)
        self.b_undo = tk.Button(row3, command=self.undo, bg=CARD, fg=INK,
                                relief='flat', padx=10, pady=4)
        self.b_undo.pack(side='left', padx=3)
        self.tree = ttk.Treeview(s3, columns=('old', 'new'), show='headings', height=12)
        self.tree.pack(fill='both', expand=True, pady=4)

        self.status = tk.Label(self.root, bg=CREAM, fg='#9A8F7F', font=('Malgun Gothic', 9))
        self.status.pack(fill='x', padx=16)
        self.gift = tk.Label(self.root, bg=CREAM, fg=SAGE, font=('Malgun Gothic', 9))
        self.gift.pack(fill='x', padx=16, pady=(0, 8))

    def retext(self):
        t = self.t
        self.root.title(t('app'))
        self.title_lbl.config(text=f"🏷 {t('app')} — {t('tagline')}")
        self.free_lbl.config(text=t('free'))
        self.lang_btn.config(text='한국어' if t.lang == 'en' else 'EN')
        self.s1_lbl.config(text=t('step1')); self.s2_lbl.config(text=t('step2'))
        self.s3_lbl.config(text=t('step3'))
        self.b_files.config(text=t('pick_files')); self.b_folder.config(text=t('pick_folder'))
        self.count_lbl.config(text=t('files_n', n=len(self.paths)) if self.paths else t('no_file'))
        for m, bt in self.mode_btns.items():
            bt.config(text=t(f'mode_{m}'))
        self.b_prev.config(text=t('preview')); self.b_run.config(text=t('run'))
        self.b_undo.config(text=t('undo'))
        self.tree.heading('old', text=t('col_old')); self.tree.heading('new', text=t('col_new'))
        self.status.config(text=t('promise'))
        self.gift.config(text=t('gift'))
        self.on_mode()

    def toggle_lang(self):
        self.t.toggle(); self.retext()

    def on_mode(self):
        t = self.t
        for w in (self.e1_lbl, self.e1, self.e2_lbl, self.e2, self.hint_lbl):
            w.pack_forget()
        m = self.mode.get()
        if m == 'replace':
            self.e1_lbl.config(text=t('find')); self.e2_lbl.config(text=t('repl'))
            self.e1_lbl.pack(side='left'); self.e1.pack(side='left', padx=4)
            self.e2_lbl.pack(side='left'); self.e2.pack(side='left', padx=4)
        elif m in ('prefix', 'suffix'):
            self.e1_lbl.config(text=t('text'))
            self.e1_lbl.pack(side='left'); self.e1.pack(side='left', padx=4)
        elif m == 'number':
            self.e1_lbl.config(text=t('base')); self.e2_lbl.config(text=t('start'))
            self.e1_lbl.pack(side='left'); self.e1.pack(side='left', padx=4)
            self.e2_lbl.pack(side='left'); self.e2.pack(side='left', padx=4)
        else:
            self.hint_lbl.config(text=t('date_hint')); self.hint_lbl.pack(side='left')

    def pick_files(self):
        ps = filedialog.askopenfilenames(parent=self.root)
        if ps:
            self.paths = sorted(ps, key=lambda p: core.natural_key(os.path.basename(p)))
            self.retext()

    def pick_folder(self):
        d = filedialog.askdirectory(parent=self.root)
        if d:
            fs = [os.path.join(d, f) for f in os.listdir(d)
                  if os.path.isfile(os.path.join(d, f))]
            self.paths = sorted(fs, key=lambda p: core.natural_key(os.path.basename(p)))
            self.retext()

    def rule(self):
        m = self.mode.get()
        r = {'mode': m}
        if m == 'replace':
            r['find'] = self.e1.get(); r['repl'] = self.e2.get()
        elif m in ('prefix', 'suffix'):
            r['text'] = self.e1.get()
        elif m == 'number':
            r['base'] = self.e1.get() or None
            try:
                r['start'] = int(self.e2.get() or 1)
            except ValueError:
                r['start'] = 1
        return r

    def preview(self):
        self.plan = core.build_plan(self.paths, self.rule())
        self.tree.delete(*self.tree.get_children())
        for old, new in self.plan:
            self.tree.insert('', 'end', values=(os.path.basename(old),
                                                os.path.basename(new)))
        if not self.plan:
            self.status.config(text=self.t('no_change'))
        else:
            self.status.config(text=self.t('files_n', n=len(self.plan)))

    def run(self):
        if not self.plan:
            self.preview()
        if not self.plan:
            return
        done, errors, log = core.apply_plan(self.plan, log_dir())
        self.last_log = log
        msg = self.t('done', n=len(done))
        if errors:
            msg += self.t('done_err', e=len(errors))
        self.status.config(text=msg)
        self.paths = [n for _, n in done]
        self.plan = []
        self.tree.delete(*self.tree.get_children())

    def undo(self):
        log = self.last_log
        if not log:
            logs = sorted(f for f in os.listdir(log_dir()) if f.endswith('.json'))
            log = os.path.join(log_dir(), logs[-1]) if logs else None
        if not log or not os.path.exists(log):
            self.status.config(text=self.t('no_log'))
            return
        restored, _ = core.undo_from_log(log)
        os.remove(log)
        self.last_log = None
        self.status.config(text=self.t('undone', n=len(restored)))
        self.tree.delete(*self.tree.get_children())


def main():
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == '__main__':
    main()
